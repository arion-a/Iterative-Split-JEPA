"""Iterative SplitJEPA experimental harness."""
