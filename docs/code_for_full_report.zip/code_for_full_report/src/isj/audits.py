"""Measurements against ground truth and the per-rung audits (monograph §8.1, §10)."""

from __future__ import annotations

import math

import torch

from .engine import RungFit


# ---------------------------------------------------------------- subspaces
def orth(a: torch.Tensor) -> torch.Tensor:
    q, _ = torch.linalg.qr(a.double())
    return q


def principal_angles_deg(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Canonical angles (degrees, ascending cosines -> descending angles) between col-spaces."""
    qa, qb = orth(a), orth(b)
    s = torch.linalg.svdvals(qa.T @ qb).clamp(0.0, 1.0)
    return torch.rad2deg(torch.acos(s))


def max_angle_deg(a: torch.Tensor, b: torch.Tensor) -> float:
    return float(principal_angles_deg(a, b).max())


def capture(basis: torch.Tensor, target: torch.Tensor) -> float:
    """Fraction of `basis` energy lying in span(target): ||target^T basis||_F^2 / dim(basis)."""
    q = orth(target)
    b = orth(basis)
    return float((q.T @ b).square().sum() / b.shape[1])


# ---------------------------------------------------------------- regression probes
def _with_intercept(x: torch.Tensor) -> torch.Tensor:
    return torch.cat([x, torch.ones(len(x), 1, dtype=x.dtype)], dim=1)


def ridge_fit(x: torch.Tensor, y: torch.Tensor, ridge: float = 1e-6) -> torch.Tensor:
    xa = _with_intercept(x.double())
    reg = ridge * len(xa) * torch.eye(xa.shape[1], dtype=xa.dtype)
    reg[-1, -1] = 0
    return torch.linalg.solve(xa.T @ xa + reg, xa.T @ y.double())


def r2(w: torch.Tensor, x: torch.Tensor, y: torch.Tensor) -> float:
    pred = _with_intercept(x.double()) @ w
    y = y.double()
    return float(1 - (y - pred).square().sum() / (y - y.mean(0)).square().sum())


def linear_r2(x_tr, y_tr, x_te, y_te, ridge: float = 1e-6) -> float:
    return r2(ridge_fit(x_tr, y_tr, ridge), x_te, y_te)


def mlp_r2(x_tr, y_tr, x_te, y_te, hidden: int = 64, steps: int = 800, lr: float = 3e-3, seed: int = 0) -> float:
    """Held-out R2 of a small two-layer tanh network fitted from x to y (a nonlinear 'is it present' probe).
    Uses its own generator, so it never touches the global random state."""
    g = torch.Generator().manual_seed(seed)
    mu, sd = x_tr.mean(0), x_tr.std(0) + 1e-8
    ym, ys = y_tr.mean(0), y_tr.std(0) + 1e-8
    xt, yt = (x_tr - mu) / sd, (y_tr - ym) / ys
    xe = (x_te - mu) / sd
    w1 = (torch.randn(xt.shape[1], hidden, generator=g) / xt.shape[1] ** 0.5).requires_grad_()
    b1 = torch.zeros(hidden, requires_grad=True)
    w2 = (torch.randn(hidden, yt.shape[1], generator=g) / hidden ** 0.5).requires_grad_()
    b2 = torch.zeros(yt.shape[1], requires_grad=True)
    opt = torch.optim.Adam([w1, b1, w2, b2], lr=lr)
    for _ in range(steps):
        idx = torch.randint(0, xt.shape[0], (1024,), generator=g)
        loss = ((torch.tanh(xt[idx] @ w1 + b1) @ w2 + b2 - yt[idx]) ** 2).mean()
        opt.zero_grad(); loss.backward(); opt.step()
    with torch.no_grad():
        pred = (torch.tanh(xe @ w1 + b1) @ w2 + b2) * ys + ym
        return float(1 - (y_te - pred).square().sum() / (y_te - y_te.mean(0)).square().sum())


# ---------------------------------------------------------------- permutation tests
def holm(pvals: list[float], alpha: float) -> list[bool]:
    """Holm step-down: True where the null is rejected."""
    order = sorted(range(len(pvals)), key=lambda i: pvals[i])
    reject = [False] * len(pvals)
    for rank, i in enumerate(order):
        if pvals[i] <= alpha / (len(pvals) - rank):
            reject[i] = True
        else:
            break
    return reject


def leakage_test(z_src_tr, y_tr, z_src_te, y_te, n_perm: int = 1000, ridge: float = 1e-6,
                 seed: int = 0) -> dict:
    """L_{j->k} = held-out R^2(z_j -> g_k) with a permutation null (monograph §10).

    Null: the test-set pairing between z_j and g_k is shuffled.
    """
    w = ridge_fit(z_src_tr, y_tr, ridge)
    obs = r2(w, z_src_te, y_te)
    g = torch.Generator().manual_seed(seed)
    n = len(z_src_te)
    pred = _with_intercept(z_src_te.double()) @ w
    y = y_te.double()
    sst = (y - y.mean(0)).square().sum()
    null = []
    for _ in range(n_perm):
        yp = y[torch.randperm(n, generator=g)]
        null.append(float(1 - (yp - pred).square().sum() / sst))
    p = (1 + sum(v >= obs for v in null)) / (1 + n_perm)
    return {"r2": obs, "p": p, "null_max": max(null), "null_mean": sum(null) / len(null)}


def leakage_matrix(blocks_est: dict[str, tuple[torch.Tensor, torch.Tensor]],
                   blocks_true: dict[str, tuple[torch.Tensor, torch.Tensor]],
                   alpha: float = 0.01, n_perm: int = 1000, seed: int = 0) -> dict:
    """Full R^2(true_j -> est_k) matrix with Holm-corrected permutation tests on off-diagonals.

    Each dict maps a name to (train, test) arrays. Diagonal entries (matching names) are the
    own-block recovery and are reported but not tested.
    """
    out, tests, keys = {}, [], []
    for kn, (e_tr, e_te) in blocks_est.items():
        for jn, (t_tr, t_te) in blocks_true.items():
            res = leakage_test(t_tr, e_tr, t_te, e_te, n_perm=n_perm, seed=seed)
            out[f"{jn}->{kn}"] = res
            if jn != kn:
                keys.append(f"{jn}->{kn}")
                tests.append(res["p"])
    rej = holm(tests, alpha) if tests else []
    for key, r in zip(keys, rej):
        out[key]["significant"] = bool(r)
    return {"entries": out, "any_significant": any(rej), "alpha": alpha}


# ---------------------------------------------------------------- rung-acceptance criteria
def gaussian_entropy_bits(cov: torch.Tensor) -> float:
    """H = 0.5 log2((2 pi e)^d det Sigma)."""
    d = cov.shape[0]
    sign, logdet = torch.linalg.slogdet(cov.double())
    return float(0.5 * (d * math.log2(2 * math.pi * math.e) + logdet / math.log(2)))


def compression_ok(content_prev: torch.Tensor, content_new: torch.Tensor) -> tuple[bool, float, float]:
    """(b): strictly fewer bits than the rung below (Gaussian entropy of the content)."""
    def bits(c):
        c = c.double() - c.double().mean(0)
        cov = c.T @ c / (len(c) - 1) if c.shape[1] else torch.zeros(0, 0)
        return gaussian_entropy_bits(cov) if c.shape[1] else 0.0
    b_prev, b_new = bits(content_prev), bits(content_new)
    return b_new < b_prev, b_prev, b_new


def predictive_loss(r_t: torch.Tensor, r_t1: torch.Tensor, ridge: float = 1e-6) -> float:
    """Equal-capacity linear predictor loss E||F r_t - r_{t+1}||^2 (held-in; use held-out splits)."""
    w = ridge_fit(r_t, r_t1, ridge)
    pred = _with_intercept(r_t.double()) @ w
    return float((pred - r_t1.double()).square().sum(1).mean())


def sufficiency(rt_prev, rt1_prev, rt_new, rt1_new, delta_s: float = 0.05) -> tuple[bool, float]:
    """(c): rho_k = L_pred(H_k)/L_pred(H_{k-1}) <= 1 + delta_s."""
    rho = predictive_loss(rt_new, rt1_new) / predictive_loss(rt_prev, rt1_prev)
    return rho <= 1 + delta_s, rho


def nesting_angle_deg(prev: RungFit | None, fit: RungFit) -> float:
    """(d), audit side: how far the new variant directions lie outside H_{k-1}.

    Holds by construction (V ⊂ H_{k-1}); the audit value should be ~0 up to float error.
    """
    if prev is None:
        return 0.0
    resid = fit.V - orth(prev.Q) @ (orth(prev.Q).T @ fit.V)
    return float(torch.rad2deg(torch.asin(resid.norm(dim=0).clamp(max=1.0).max())))


def rank_deficient(m: torch.Tensor, n: int, bound: float, delta: float = 0.01) -> bool:
    """Termination test (§10): lambda_min <= B^2 sqrt(2 log(1/delta)/n)."""
    lam_min = float(torch.linalg.eigvalsh(m.double()).min())
    return lam_min <= bound**2 * math.sqrt(2 * math.log(1 / delta) / n)



def rank_monitor(fit: RungFit, delta: float = 0.01) -> dict:
    """Rank-completeness monitor (decision D9): lambda_min of the pair-difference moment on the estimated variant subspace
    against the monograph's section-10 noise floor B^2 sqrt(2 log(1/delta) / n). pass = the pairs vary every variant direction."""
    lam = float(fit.eigvals[fit.d_k - 1])
    thr = fit.max_sq_diff * math.sqrt(2 * math.log(1 / delta) / fit.n_pairs)
    return {"lambda_min": lam, "threshold": thr, "pass": lam > thr, "n_pairs": fit.n_pairs}
